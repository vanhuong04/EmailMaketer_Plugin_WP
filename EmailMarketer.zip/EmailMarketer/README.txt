=== EmailMarketer ===
Contributors: your-wordpress-username
Donate link: https://example.com/
Tags: email marketing, email collection, excel export
Requires at least: 5.2
Tested up to: 6.2
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

EmailMarketer là plugin mạnh mẽ giúp bạn thu thập email người dùng trong WordPress và gửi email marketing đến một hoặc nhiều email cùng lúc. Plugin còn có chức năng xuất danh sách email và tên tài khoản ra file Excel, giúp bạn dễ dàng quản lý và tiếp cận người dùng.

== Description ==

EmailMarketer là plugin mạnh mẽ giúp bạn thu thập email người dùng trong WordPress và gửi email marketing đến một hoặc nhiều email cùng lúc. Plugin còn có chức năng xuất danh sách email và tên tài khoản ra file Excel, giúp bạn dễ dàng quản lý và tiếp cận người dùng.

== Installation ==

1. Tải tệp plugin lên thư mục `/wp-content/plugins/` hoặc cài đặt plugin trực tiếp thông qua trang plugin của WordPress.
2. Kích hoạt plugin thông qua menu 'Plugins' trong WordPress.
3. Định cấu hình plugin bằng cách truy cập `EmailMarketer` trong menu quản trị.

== Frequently Asked Questions ==

= Plugin này có miễn phí không? =

Có, EmailMarketer là plugin miễn phí và tuân theo giấy phép GPLv2 hoặc sau này.

= Tôi cần hỗ trợ, tôi nên làm gì? =

Nếu bạn cần hỗ trợ, vui lòng liên hệ với chúng tôi qua trang [hỗ trợ](https://vnblog.id.vn).

== Screenshots ==

1. Trang quản trị EmailMarketer.
2. Gửi email marketing cho nhiều người nhận cùng lúc.
3. Xuất danh sách email ra file Excel.

== Changelog ==

= 1.0.0 =
* Phát hành phiên bản đầu tiên.

== Upgrade Notice ==

= 1.0.0 =
Phát hành phiên bản đầu tiên của EmailMarketer.

== Arbitrary section ==

Bạn có thể sử dụng phần này để thêm bất kỳ thông tin nào mà bạn muốn chia sẻ với người dùng của mình.

== License ==

EmailMarketer được cấp phép theo giấy phép GPLv2 hoặc sau này.
