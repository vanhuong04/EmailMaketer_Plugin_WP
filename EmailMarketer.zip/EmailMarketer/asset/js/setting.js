
jQuery(document).ready(function ($) {
    $("#button__setting").on("click", function (e) {
        console.log('gsadg');
        let email = $('#your_email').val()
        let password = $('#password__app').val()

        // e.preventDefault();
        var postData = 'action=settingEmail&param=setting&email=' + email + '&password=' + password;
        jQuery.post(ajaxurl.baseURL, postData, (res) => {
            console.log(res);
        })
    });


});