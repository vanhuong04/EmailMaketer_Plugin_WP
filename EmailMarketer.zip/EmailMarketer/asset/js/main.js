new DataTable('#example');
let search_name = document.querySelector('.dt-search label');
let count_per_page = document.querySelector('.dt-length label');
let selet_count = document.querySelector('.dt-input');
let checks = document.querySelectorAll('#example input[type="checkbox"]');
let check_all = document.getElementById('check__all');

search_name.textContent = 'Tìm kiếm ';
count_per_page.textContent = ' Đối tượng trên mỗi trang';
selet_count.style.width = '45px';

// Hàm để kiểm tra hoặc bỏ kiểm tất cả checkbox
check_all.addEventListener('change', function () {
    checks.forEach((checkbox) => {
        checkbox.checked = check_all.checked;
    });
});

// Hàm để kiểm tra trạng thái của tất cả các checkbox và cập nhật checkbox "Check All"
checks.forEach((checkbox) => {
    checkbox.addEventListener('change', function () {
        if (!checkbox.checked) {
            check_all.checked = false;
        } else {
            let allChecked = true;
            checks.forEach((cb) => {
                if (!cb.checked) {
                    allChecked = false;
                }
            });
            check_all.checked = allChecked;
        }
    });
});



jQuery(document).ready(function ($) {

    $(".button").on("click", function (e) {
        const elements = $('input[type="checkbox"]:checked').map(function () {
            return $(this).data('email');
        }).get();
        console.log(elements);
        let content = $('#content').val()
        let subject = $('.subject').val()
        elements.forEach(function (email) {

            var postData = 'action=sendEmail&param=email&email=' + email + '&content=' + content + '&subject=' + subject;
            jQuery.post(ajaxurl.baseURL, postData, (res) => {
                console.log(res);
            })
        })
    });

});

document.getElementById('exportButton').addEventListener('click', function () {
    var table = document.querySelector('.myTable');
    var wb = XLSX.utils.table_to_book(table, { sheet: "Sheet JS" });
    XLSX.writeFile(wb, 'exported_table.xlsx');
});




