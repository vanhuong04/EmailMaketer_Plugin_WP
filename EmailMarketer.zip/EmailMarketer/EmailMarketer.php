<?php
/*
 * Plugin Name:       EmailMarketer
 * Plugin URI:        #
 * Description:       EmailMarketer là plugin mạnh mẽ giúp bạn thu thập email người dùng trong WordPress và gửi email marketing đến một hoặc nhiều email cùng lúc. Plugin còn có chức năng xuất danh sách email và tên tài khoản ra file Excel, giúp bạn dễ dàng quản lý và tiếp cận người dùng.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Pham Van Huong
 * Author URI:        https://vbnlog.info.vn
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       EmailMarketer
 * Domain Path:       /languages
 */


define('EMAIL_URI', plugin_dir_url(__FILE__));
define('EMAIL_PATH', plugin_dir_path(__FILE__));


if (!class_exists('MY_CLASS')) {
    class MY_CLASS
    {
        public function __construct()
        {
            add_action('admin_enqueue_scripts', [$this, 'load_assets']);
            add_action('admin_menu', [$this, 'custom_admin_menu']);
        }

        function custom_admin_menu()
        {
            add_menu_page('Setting', 'EmailMarketer', 'manage_options', 'emailmkt-setting', [$this, 'render_setting'], EMAIL_URI . 'asset/img/envelope-at.svg', 1);
            add_submenu_page('emailmkt-setting', 'Send email', 'Send email', 'manage_options', 'emailmkt-send', [$this, 'render_send']);
            add_submenu_page('emailmkt-setting', 'Setting', 'Setting', 'manage_options', 'emailmkt-setting', [$this, 'render_setting']);
        }


        function render_send()
        {
            include_once (EMAIL_PATH . '/views/all_email.php');

        }

        function render_setting()
        {
            include_once (EMAIL_PATH . '/views/setting_email.php');

        }

        // nhúng js và css
        function load_assets()
        {
            wp_enqueue_style('css', EMAIL_URI . 'asset/style/main.css', [], '1.0.0', 'all');
            // wp_enqueue_style( 'dataTableCSS', 'https://cdn.datatables.net/v/dt/dt-2.0.8/datatables.min.css',[],'1.0.0', 'all' );
            wp_enqueue_script('js', EMAIL_URI . 'asset/js/main.js', array('jquery'), '1.0.0', true);
            wp_enqueue_script('setting-js', EMAIL_URI . 'asset/js/setting.js', array('jquery'), '1.0.0', true);
            // wp_enqueue_script( 'dataTableJS', 'https://cdn.datatables.net/v/dt/dt-2.0.8/datatables.min.js', [], '1.0.0', true );

            wp_localize_script('js', 'ajaxurl', [
                'baseURL' => admin_url("admin-ajax.php")
            ]);
        }

        // tao database
        function create_table()
        {
            global $wpdb;
            $table_name = $wpdb->prefix . 'email_mkt';

            $sql = "
                    CREATE TABLE $table_name (
                     `id` INT(11) NOT NULL AUTO_INCREMENT,
	                `email` VARCHAR(200) NULL DEFAULT NULL COLLATE 'utf8mb4_0900_ai_ci',
	                `password` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_0900_ai_ci',
                      PRIMARY KEY (`id`)
                     )
                    COLLATE='utf8mb4_0900_ai_ci'
                    ENGINE=InnoDB;";

            include_once ABSPATH . '/wp-admin/includes/upgrade.php';
            dbDelta($sql);
        }

       

    }

}
include_once (EMAIL_PATH . '/includes/send_mail.php');
include_once (EMAIL_PATH . '/includes/setting_mail.php');


$class = new MY_CLASS();
function crop_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'email_mkt';
    $sql = "DROP TABLE IF EXISTS $table_name";

    $wpdb->query($sql);
}

register_activation_hook(__FILE__, [$class, 'create_table']);
register_uninstall_hook(__FILE__, 'crop_table');
