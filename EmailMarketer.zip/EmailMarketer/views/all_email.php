<?php

global $wpdb;

$query = 'SELECT user_email FROM wp_users';

$results = $wpdb->get_results($query, ARRAY_A);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div class="all__body">
        <form action="" class="form"> 
            <div class="all__title">Gửi Mail</div>
            <div class="content">
                <input type="text" name="" id="" class="subject" placeholder="Tiêu đề">
                <textarea name="" id="content" placeholder="nội dung cần gửi"></textarea>
            </div>
          <div class="all__group">
          <div class="button">Gửi</div>
          <button id="exportButton">Xuất file Excel</button>
          </div>
        </form>

        <table id="example" class="display myTable" style="width:100%">
            <thead>
                <tr>
                    <th>Tên</th>
                    <th>Email</th>
                    <th><input type="checkbox" name="" id="check__all"></th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Duyệt mảng lấy thông tin
                if ($results) {
                    foreach ($results as $result) {
                        ?>
                        <tr>
                            <!-- lấy user login -->
                            <td>
                                <?php
                                $the_user = get_user_by('email', $result['user_email']);
                                $arr = (array) $the_user;
                                $data = $arr['data'];
                                $user_login = (array) $data;
                                echo esc_html($user_login['user_login']); ?>
                            </td>

                            <!-- lấy email -->
                            <td><?php echo esc_html($result['user_email']); ?></td>
                            <td><input type="checkbox" name="" id=""
                                    data-email="<?php echo esc_html($result['user_email']); ?>">
                            </td>
                        </tr>
                        <?php
                    }
                } ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Tên</th>
                    <th>Email</th>
                    <th>Chọn</th>
                </tr>
            </tfoot>
        </table>
        
    </div>

    <link href="https://cdn.datatables.net/v/dt/dt-2.0.8/datatables.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/v/dt/dt-2.0.8/datatables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.5/xlsx.full.min.js"></script>
</body>

</html>