<?php
global $wpdb;
$query = 'SELECT * FROM wp_email_mkt';

$results = $wpdb->get_results($query, ARRAY_A);

?>

<div class="PW">
    <div>CẤU HÌNH EMAIL CỦA BẠN</div>
   <div class="setting__body">
   <div>
        <label for="your_email">Email</label>
        <input type="email" name="your_email" id="your_email" placeholder="nhập email của bạn" value="<?php echo $results[0]['email'] ?>">
    </div>

    <div>
        <label for="password__app">Mật khẩu</label>
        <input type="email" name="password__app" id="password__app" placeholder="nhập mật khẩu ứng dụng của bạn" value="<?php echo $results[0]['password'] ?>">
    </div>

    <div class="button__setting" id="button__setting">Lưu</div>
   </div>

   <div class="setting__noice">*Mật khẩu chính là mật khẩu úng dụng gmail của bạn chứ không phải mật khẩu tài khoản gmail</div>
</div>