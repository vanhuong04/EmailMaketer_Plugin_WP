<?php

add_action("wp_ajax_settingEmail", "setting_ajax_handler");
function setting_ajax_handler()
{
    global $wpdb;
    $existing_record = $wpdb->get_row("SELECT * FROM wp_email_mkt" ,ARRAY_A);
    print_r( $existing_record);
    if ($_REQUEST['param'] === "setting") {
        print_r($_REQUEST);
        $email = $_POST['email'];
        $password = $_POST['password'];

        if(empty($existing_record)){
            $wpdb->insert(
                'wp_email_mkt',
                array(
                    'email' => $email,
                    'password' => $password
                )
            );
        }else{
            $wpdb->update(
                'wp_email_mkt',
                array(
                    'email' => $email,
                    'password' => $password
                ),
                array(
                    'id' => $existing_record['id'] // Thay thế 'id' bằng trường phù hợp trong bảng của bạn
                )
            );
        }

      
    
    }

    wp_die();

}
