<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function

//jdzs ixac tfzg egbs

function sendMail($to_email, $subject, $message)
{
    global $wpdb;
    $query = 'SELECT * FROM wp_email_mkt';
    $results = $wpdb->get_results($query, ARRAY_A);
    $email = $results[0]['email'];
    $password = $results[0]['password'];

    add_action('phpmailer_init', function ($phpmailer) use ($email, $password) {
       
        $phpmailer->isSMTP();
        $phpmailer->Host = 'smtp.gmail.com';
        $phpmailer->SMTPAuth = true;
        $phpmailer->Port = 465; // Hoặc 587 nếu bạn sử dụng TLS
        $phpmailer->Username = $email; // Thay bằng địa chỉ email của bạn
        $phpmailer->Password = $password; // Thay bằng mật khẩu của bạn
        $phpmailer->SMTPSecure = 'ssl'; // Hoặc 'tls' nếu bạn sử dụng TLS
        $phpmailer->From = 'vanhuong77677@gmail.com'; // Địa chỉ email gửi đi
        $phpmailer->FromName = get_bloginfo('name'); // Tên người gửi
    });

    // $subject = 'Subject of the Email';
    // $message = 'heloooooooooooooooooooooooo.';
    $headers = array('Content-Type: text/html; charset=UTF-8');

    wp_mail($to_email, $subject, $message, $headers);
}




add_action("wp_ajax_sendEmail", "email_ajax_handler");

function email_ajax_handler()
{
    if ($_REQUEST['param'] === "email") {
        print_r($_REQUEST);
        $email = $_POST['email'];
        $subject = $_POST['subject'];
        $content = $_POST['content'];
        sendMail($email, $subject, $content);



    }
    wp_die();

}


// Lấy đối tượng vai trò quản trị viên

